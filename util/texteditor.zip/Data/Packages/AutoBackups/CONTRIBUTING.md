CONTRIBUTING
============

Contributions are welcome, and are accepted via pull requests. Please review these guidelines before submitting any pull requests.

## Guidelines
Before you contribute code to project, please make sure it conforms to the project coding standard.
The easiest way to contribute is to work on a checkout of the repository, or your own fork.