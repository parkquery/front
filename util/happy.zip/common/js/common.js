$(function(){

	storyHeight(); //타임라인 스타일의 목록이 나올 때 필요 (타임라인, 이벤트, 내글, 좋아요글, 관심글 등 )

	/* 타임라인 좋아요 버튼 */
	$(".timeline_list .btn_good").click(function(){
		var $this = $(this);
		if (!$this.hasClass("on")) {
			$this.addClass("on");
		} else {
			$this.removeClass("on");
		}
	});

	/* 답글 입력 */
	$(".view_comment .btn_action_reply").on("click", function(){
		var $this = $(this);
		var accountName = $this.closest(".view_comment_list").find(">.title_box .account_name a").text();
		var _top = 0;

		if (isMobile.iOS()) {
			$(".input_comment input").focus();
			$(".input_comment .notice_reply .name").text(accountName);
			$(".input_comment .notice_reply").show();
			window.setTimeout(function() {
				$(".detail_comment_inner").css("transform","matrix(1, 0, 0, 1, 0, 0)");
				_top = $this.closest(".view_comment_list").offset().top;
				$(".detail_comment_inner").css("transform","matrix(1, 0, 0, 1, 0," + -(_top) + ")");
			},100);
		} else {
			_top = $this.closest(".view_comment_list").offset().top;
			$("html,body").animate({scrollTop:_top},200 ,"easeInOutQuart");
			$(".input_comment .notice_reply .name").text(accountName);
			$(".input_comment .notice_reply").show();
			$(".input_comment input").focus();
			$(".view_comment").css("padding-bottom","39px");
		}

		$(".input_comment .input_box input[type=text]").attr("placeholder","답글을 입력해주세요");

	});
	/* 답글 입력창 아웃 */
	$(".input_comment input").on("focusout", function(){
		$(".input_comment .notice_reply").hide();
		$(".view_comment").removeAttr("style");
		$(".input_comment .input_box input[type=text]").attr("placeholder","댓글을 입력해주세요");
	});


	/* FAQ dropdown */
	$(".faq_title_button").on("click", function(){
		$(".faq_content").css("height","0");
		var $this = $(this);
		var faqOffsetTop = $this.offset().top - $("#header").height();
		var faqHeight = $this.parent().next().find(".faq_content_txt").outerHeight();
		if ( !$this.parent().hasClass("on") ) {
			$(".faq_title").removeClass("on");
			$this.parent().addClass("on").next().stop().animate({"height":faqHeight}, 300, "easeInOutQuart");
		} else {
			$this.parent().removeClass("on").next().css("height","0");
		}

	});

	/* 회원가입약관 팝업 스크롤(iScroll) 실행*/
	if ( $("#layerPopupScroll").length !== 0 ) {
		iscroll = new iScroll("layerPopupScroll" , {
			useTransform: false
		});
	}
});

/* dim layer */
var _dim = "<div class=\"layer_dim\"></div>";
var dim = $(".layer_dim");

/* 회원가입약관 전문보기 열기 */
function agreeViewOpen(target,text){
	$("body").on('touchmove', function(e) { e.preventDefault(); }); //스크롤 방지
	$this = $(target);
	var title = $this.closest("li").find("label").text();
	text = text || "약관내용을 불러오지 못했습니다.";
	$(".layer_popup .title").text(title); //약관 타이틀 변경
	$(".agreeWrap").html(text); //약관 내용 불러오기
	$this.addClass("flag_focus");
	$(".layer_popup_wrap").attr("tabindex","-1").show().focus();
	layerHeight();
}
/* 팝업 높이 설정 */
function layerHeight(){
	var _layerPopup = $(".layer_popup").height();
	var _layerTitle = $(".layer_popup .title").outerHeight();
	var _layerCont = _layerPopup - _layerTitle;
	$("#layerPopupScroll").height(_layerCont);
	window.setTimeout(function() {
		iscroll.refresh();
	},300);
}
/* 회원가입약관 전문보기 닫기 */
function agreeViewClose(){
	$("body").off('touchmove'); //스크롤 방지 해제
	$(".layer_popup_wrap").hide();
	$(".flag_focus").focus();
	//$("#header").show(); //네이티브 - 추후 삭제
	window.setTimeout(function(){
		$(".flag_focus").removeClass("flag_focus");
	},300);
}

/* 디바이스 체크 */
var isMobile = {
	Android: function () {
		return navigator.userAgent.match(/Android/i);
	},
	iOS: function () {
		return navigator.userAgent.match(/iPhone|iPad|iPod/i);
	}
};

/* 타임라인 썸네일 이미지 자르기 */
function storyHeight(){
	var storyImgHeight = $(".story_timeline .cont_img").width() * 1.1;
	$(".story_timeline .cont_img").css("max-height",storyImgHeight);
}

/* 타임라인 버튼레이어 활성화 */
function storyLayerOpen(target, list){
	var $this = $(target);
	var $thisList = $this.closest(".timeline_list");
	var $layerStory = $thisList.find(".story_layer_action"); //버튼레이어

	if ( !$layerStory.hasClass("on") ) {
		$(".story_layer_action").removeClass("on");
		$(".timeline_list .btn_action").attr("title","추가기능 팝업 열기");
		$(".action_share").hide().css("height",0); //공유하기 버튼 초기화
		var layerHeight = $layerStory.height() + 30; //레이어 영역
		$(".timeline_list").removeAttr("style","min-height");
		if ( list ) { //목록 페이지에서 활성화 되는 부분 list === true
			if ( $thisList.index() + 1 == $(".timeline_list").length ) {
				$thisList.css("min-height",layerHeight);
			}
		}
		$layerStory.addClass("on");
		$this.attr("title","추가기능 팝업 닫기");
	} else {
		storyLayerClose(target);
	}
}
/* 타임라인 버튼레이어 비활성화 */
function storyLayerClose(target){
	var $this = $(target);
	var $thisList = $this.closest(".timeline_list"); //해당 목록
	$thisList.find(".btn_action").attr("title","추가기능 팝업 열기");
	$thisList.removeAttr("style","min-height");
	$(".story_layer_action").removeClass("on");
	$(".story_layer_action .share").attr("title","공유하기 버튼 펼치기");
	$(".action_share").hide().css("height",0);
}
/* 공유하기 */
function shareOpen(target){
	var $this = $(target);
	var $thisList = $this.closest(".timeline_list"); //해당 목록
	var $layerStory = $thisList.find(".story_layer_action"); //버튼레이어
	var _shareHeight = $layerStory.find(".action_share").height();
	var layerHeight = $layerStory.height() + 55 + 30;

	if ( $thisList.index() + 1 == $(".timeline_list").length && _shareHeight == 0) {
		$(".timeline_list").removeAttr("style","min-height"); //최소값 리셋
		$thisList.css("min-height",layerHeight); //최소높이 할당
	}
	$this.removeAttr("title");
	$(".action_share").show().stop().animate({"height":"55px"}, 400, "easeInOutQuart");
}
/* 댓글의 댓글 입력 알림 창 닫기 */
function commentNoticeClose(){
	$(".input_comment .notice_reply").hide();
	$(".view_comment").removeAttr("style");
}


/* 네이티브 부분 - 편의상 임시로 만들어 둠 */
$(function(){
	$(".gnb .btn_menu").click(function(){
		var $btn = $(".gnb .btn_menu");
		if ( $btn.data("menu") != "on" ) {
			$btn.data("menu","on");
			$(".gnb_menu").stop().slideDown(200);
		} else {
			$btn.data("menu","off");
			$(".gnb_menu").stop().slideUp(200);
		}
	});
});



/* 경고창 열기 */
function alertPopupOpen(target){
	if (!$(".dim").length) { $("body").prepend(_dim); }
	$("body").on('touchmove', function(e) { e.preventDefault(); }); //스크롤 방지
	$(".layer_alert_popup").show(); //경고창 보이기
	$(".layer_alert_popup").attr("tabindex",-1).focus(); //경고창 보이기
}

/* 경고창 닫기 */
function alertPopupClose(){
	$(".layer_dim").remove();
	$("body").off('touchmove'); //스크롤 방지 해제
	$(".layer_alert_popup").hide();
}
/* [end]: 네이티브 부분 - 편의상 임시로 만들어 둠 */
